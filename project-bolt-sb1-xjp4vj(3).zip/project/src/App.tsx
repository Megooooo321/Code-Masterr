import { useState } from 'react';
import { motion } from 'framer-motion';
import { Code, Mail, Phone, MapPin, Github, Twitter, Linkedin, ArrowRight, Download, ExternalLink, Database, Layout, Server, Terminal, Workflow, Shield, Globe, Smartphone } from 'lucide-react';
import { useInView } from 'react-intersection-observer';
import './styles/globals.css';

// Logo Component
const Logo = () => (
  <motion.div 
    className="flex items-center"
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ duration: 0.5 }}
  >
    <div className="relative">
      <Code className="h-8 w-8 text-cyan-400" />
      <motion.div
        className="absolute -top-1 -right-1 w-3 h-3 bg-cyan-400 rounded-full"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.5, 1, 0.5]
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          repeatType: "reverse"
        }}
      />
    </div>
    <span className="ml-2 text-2xl font-bold text-white">
      Code<span className="text-cyan-400">Master</span>
    </span>
  </motion.div>
);

// Navbar Component
const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useState(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.nav 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-gray-900/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Logo />
          <div className="hidden md:flex items-center space-x-8">
            {['Home', 'About', 'Services', 'Projects', 'Contact'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-gray-300 hover:text-cyan-400 transition-colors"
              >
                {item}
              </a>
            ))}
          </div>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-gray-300 hover:text-white"
          >
            {isOpen ? '✕' : '☰'}
          </button>
        </div>
        
        {isOpen && (
          <div className="md:hidden py-2">
            {['Home', 'About', 'Services', 'Projects', 'Contact'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="block py-2 text-gray-300 hover:text-cyan-400"
                onClick={() => setIsOpen(false)}
              >
                {item}
              </a>
            ))}
          </div>
        )}
      </div>
    </motion.nav>
  );
};

// Hero Section
const Hero = () => (
  <section id="home" className="min-h-screen flex items-center justify-center pt-16">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <div className="glass-card rounded-2xl p-8 md:p-12 text-center md:text-left">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <span className="inline-block px-4 py-2 rounded-full bg-cyan-500/10 text-cyan-400 text-sm mb-6">
              Full Stack Developer
            </span>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Hi, I'm Ahmed
              <span className="text-cyan-400"> Magdy Farouk</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Full-stack developer specializing in creating innovative web solutions.
              Turning complex problems into elegant, user-friendly applications.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button className="btn-primary flex items-center">
                View Projects
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
              <button className="btn-secondary flex items-center">
                Contact Me
                <Mail className="ml-2 h-5 w-5" />
              </button>
            </div>
            <div className="flex gap-4">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-gray-800/50 text-gray-400 hover:text-cyan-400 transition-colors"
              >
                <Github className="h-5 w-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-gray-800/50 text-gray-400 hover:text-cyan-400 transition-colors"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-gray-800/50 text-gray-400 hover:text-cyan-400 transition-colors"
              >
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>
          <div className="hidden md:block">
            <img
              src="https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?auto=format&fit=crop&w=800&q=80"
              alt="Ahmed Magdy"
              className="rounded-full w-80 h-80 object-cover mx-auto border-4 border-cyan-400/20"
            />
          </div>
        </div>
      </div>
    </div>
  </section>
);

// About Section
const About = () => {
  const stats = [
    { label: 'Years Experience', value: '3+', icon: Terminal },
    { label: 'Projects Completed', value: '50+', icon: Layout },
    { label: 'Satisfied Clients', value: '30+', icon: Shield },
    { label: 'Certifications', value: '5+', icon: Globe }
  ];

  return (
    <section id="about" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
            About <span className="text-cyan-400">Me</span>
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold text-white mb-6">
                Passionate Web Developer & Problem Solver
              </h3>
              <div className="space-y-4 text-gray-300">
                <p>
                  As a full-stack developer, I specialize in creating modern web applications
                  that combine beautiful design with powerful functionality.
                </p>
                <p>
                  My expertise spans both front-end and back-end development, allowing me
                  to build complete solutions from start to finish.
                </p>
                <p>
                  I'm passionate about creating user-friendly interfaces and writing clean,
                  efficient code that solves real-world problems.
                </p>
              </div>
              <div className="mt-8 flex flex-wrap gap-4">
                <button className="btn-primary">
                  Download CV
                  <Download className="ml-2 h-5 w-5" />
                </button>
                <button className="btn-secondary">
                  View Certificates
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat) => (
                <div key={stat.label} className="p-6 rounded-xl bg-gray-800/50 hover:bg-gray-800/70 transition-colors">
                  <stat.icon className="h-8 w-8 text-cyan-400 mb-4" />
                  <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                  <div className="text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Services Section
const Services = () => {
  const services = [
    {
      icon: Layout,
      title: 'Frontend Development',
      description: 'Creating responsive and interactive user interfaces using React, HTML5, CSS3, and modern JavaScript.'
    },
    {
      icon: Server,
      title: 'Backend Development',
      description: 'Building robust server-side applications with Node.js, Express, and various databases.'
    },
    {
      icon: Database,
      title: 'Database Design',
      description: 'Designing and implementing efficient database structures using SQL and NoSQL solutions.'
    },
    {
      icon: Smartphone,
      title: 'Mobile Development',
      description: 'Cross-platform mobile apps using React Native and Flutter.'
    },
    {
      icon: Globe,
      title: 'Web Services',
      description: 'RESTful APIs and GraphQL implementations for seamless integration.'
    },
    {
      icon: Shield,
      title: 'Security Solutions',
      description: 'Implementation of security best practices and authentication systems.'
    }
  ];

  return (
    <section id="services" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
            My <span className="text-cyan-400">Services</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="p-6 rounded-xl bg-gray-800/50 hover:bg-gray-800/70 transition-all duration-300 transform hover:-translate-y-2"
              >
                <service.icon className="h-12 w-12 text-cyan-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                <p className="text-gray-400">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// Projects Section
const Projects = () => {
  const projects = [
    {
      title: 'AI Code Assistant',
      description: 'Real-time code analysis and suggestions powered by machine learning',
      image: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=800&q=80',
      tags: ['React', 'Python', 'TensorFlow'],
      github: '#',
      demo: '#'
    },
    {
      title: 'Cloud DevOps Platform',
      description: 'Automated deployment and scaling solution for cloud applications',
      image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80',
      tags: ['Docker', 'Kubernetes', 'AWS'],
      github: '#',
      demo: '#'
    },
    {
      title: 'Blockchain Explorer',
      description: 'Interactive blockchain visualization and analysis tool',
      image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80',
      tags: ['Web3.js', 'Node.js', 'D3.js'],
      github: '#',
      demo: '#'
    }
  ];

  return (
    <section id="projects" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
            Featured <span className="text-cyan-400">Projects</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div
                key={index}
                className="rounded-xl overflow-hidden bg-gray-800/50 hover:bg-gray-800/70 transition-all duration-300 transform hover:-translate-y-2"
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-2">{project.title}</h3>
                  <p className="text-gray-400 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className="px-3 py-1 rounded-full text-sm bg-cyan-500/10 text-cyan-400"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-4">
                    <a
                      href={project.github}
                      className="flex items-center text-gray-400 hover:text-cyan-400 transition-colors"
                    >
                      <Github className="h-5 w-5 mr-2" />
                      Code
                    </a>
                    <a
                      href={project.demo}
                      className="flex items-center text-gray-400 hover:text-cyan-400 transition-colors"
                    >
                      <ExternalLink className="h-5 w-5 mr-2" />
                      Demo
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// Contact Section
const Contact = () => (
  <section id="contact" className="py-20">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="glass-card rounded-2xl p-8 md:p-12">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
          Get in <span className="text-cyan-400">Touch</span>
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-white mb-6">Contact Information</h3>
            <p className="text-gray-300 mb-8">
              Feel free to reach out for collaborations or just a friendly hello
            </p>
            
            <div className="flex items-center space-x-4">
              <div className="p-3 rounded-lg bg-cyan-500/10">
                <Phone className="h-6 w-6 text-cyan-400" />
              </div>
              <div>
                <h4 className="text-white font-medium">Phone</h4>
                <p className="text-gray-400">+20 1032920995</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="p-3 rounded-lg bg-cyan-500/10">
                <Mail className="h-6 w-6 text-cyan-400" />
              </div>
              <div>
                <h4 className="text-white font-medium">Email</h4>
                <p className="text-gray-400">megoo447711@gmail.com</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="p-3 rounded-lg bg-cyan-500/10">
                <MapPin className="h-6 w-6 text-cyan-400" />
              </div>
              <div>
                <h4 className="text-white font-medium">Location</h4>
                <p className="text-gray-400">Cairo, Egypt</p>
              </div>
            </div>
          </div>

          <form className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                Name
              </label>
              <input
                type="text"
                id="name"
                className="w-full px-4 py-3 rounded-lg bg-gray-800/50 border border-gray-700 text-white focus:ring-2 focus:ring-cyan-400 focus:border-transparent"
                placeholder="Your name"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                Email
              </label>
              <input
                type="email"
                id="email"
                className="w-full px-4 py-3 rounded-lg bg-gray-800/50 border border-gray-700 text-white focus:ring-2 focus:ring-cyan-400 focus:border-transparent"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                Message
              </label>
              <textarea
                id="message"
                rows={4}
                className="w-full px-4 py-3 rounded-lg bg-gray-800/50 border border-gray-700 text-white focus:ring-2 focus:ring-cyan-400 focus:border-transparent"
                placeholder="Your message"
              ></textarea>
            </div>

            <button
              type="submit"
              className="btn-primary w-full flex items-center justify-center"
            >
              Send Message
              <Mail className="ml-2 h-5 w-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>
);

// Footer Component
const Footer = () => (
  <footer className="bg-gray-900/50 backdrop-blur-sm border-t border-gray-800">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="col-span-1 md:col-span-2">
          <Logo />
          <p className="text-gray-400 my-6">
            Transforming ideas into exceptional digital experiences. Specializing in modern web development,
            scalable architecture, and innovative solutions.
          </p>
          <div className="flex space-x-4">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg bg-gray-800/50 text-gray-400 hover:text-cyan-400 transition-colors"
            >
              <Github className="h-5 w-5" />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg bg-gray-800/50 text-gray-400 hover:text-cyan-400 transition-colors"
            >
              <Twitter className="h-5 w-5" />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg bg-gray-800/50 text-gray-400 hover:text-cyan-400 transition-colors"
            >
              <Linkedin className="h-5 w-5" />
            </a>
          </div>
        </div>

        <div>
          <h3 className="text-white font-semibold mb-4">Quick Links</h3>
          <ul className="space-y-3">
            {['Home', 'About', 'Services', 'Projects', 'Contact'].map((item) => (
              <li key={item}>
                <a
                  href={`#${item.toLowerCase()}`}
                  className="text-gray-400 hover:text-cyan-400 transition-colors"
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-white font-semibold mb-4">Services</h3>
          <ul className="space-y-3">
            {[
              'Web Development',
              'Mobile Apps',
              'UI/UX Design',
              'Cloud Solutions',
              'API Integration'
            ].map((service) => (
              <li key={service}>
                <a
                  href="#services"
                  className="text-gray-400 hover:text-cyan-400 transition-colors"
                >
                  {service}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-12 pt-8 border-t border-gray-800">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © {new Date().getFullYear()} CodeMaster. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-cyan-400 text-sm">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-cyan-400 text-sm">Terms of Service</a>
            <a href="#" className="text-gray-400 hover:text-cyan-400 text-sm">Cookie Policy</a>
          </div>
        </div>
      </div>
    </div>
  </footer>
);

// Main App Component
function App() {
  return (
    <div className="min-h-screen bg-pattern">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Projects />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;