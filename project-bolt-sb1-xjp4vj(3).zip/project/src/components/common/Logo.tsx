import { Code } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Logo() {
  return (
    <motion.div 
      className="flex items-center"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="relative">
        <Code className="h-8 w-8 text-cyan-400" />
        <motion.div
          className="absolute -top-1 -right-1 w-3 h-3 bg-cyan-400 rounded-full"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 1, 0.5]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
      </div>
      <span className="ml-2 text-2xl font-bold text-white">
        Code<span className="text-cyan-400">Master</span>
      </span>
    </motion.div>
  );
}