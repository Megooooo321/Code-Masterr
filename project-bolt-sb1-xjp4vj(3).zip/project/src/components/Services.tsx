import { Code, Smartphone, Database, Globe, Gauge, Shield } from 'lucide-react';

const services = [
  {
    icon: Code,
    title: 'Frontend Development',
    description: 'Modern and responsive web applications using React, Vue, and Angular'
  },
  {
    icon: Database,
    title: 'Backend Development',
    description: 'Scalable server solutions with Node.js, Python, and databases'
  },
  {
    icon: Smartphone,
    title: 'Mobile Development',
    description: 'Cross-platform mobile apps using React Native and Flutter'
  },
  {
    icon: Globe,
    title: 'Web Services',
    description: 'RESTful APIs and GraphQL implementations for seamless integration'
  },
  {
    icon: Gauge,
    title: 'Performance Optimization',
    description: 'Speed optimization and caching strategies for better user experience'
  },
  {
    icon: Shield,
    title: 'Security Solutions',
    description: 'Implementation of security best practices and authentication systems'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Services</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Comprehensive development solutions tailored to your needs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="p-6 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <service.icon className="h-12 w-12 text-indigo-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">{service.title}</h3>
              <p className="text-gray-400">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}