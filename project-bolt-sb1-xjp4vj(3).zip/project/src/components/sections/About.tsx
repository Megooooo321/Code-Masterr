import { Award, BookOpen, Briefcase, Users } from 'lucide-react';

const stats = [
  { label: 'Years Experience', value: '3+', icon: Briefcase },
  { label: 'Projects Completed', value: '50+', icon: BookOpen },
  { label: 'Satisfied Clients', value: '30+', icon: Users },
  { label: 'Certifications', value: '5+', icon: Award }
];

export default function About() {
  return (
    <section id="about" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
            About <span className="text-cyan-400">Me</span>
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold text-white mb-6">
                Passionate Web Developer & Problem Solver
              </h3>
              <div className="space-y-4 text-gray-300">
                <p>
                  As a full-stack developer, I specialize in creating modern web applications
                  that combine beautiful design with powerful functionality.
                </p>
                <p>
                  My expertise spans both front-end and back-end development, allowing me
                  to build complete solutions from start to finish.
                </p>
                <p>
                  I'm passionate about creating user-friendly interfaces and writing clean,
                  efficient code that solves real-world problems.
                </p>
              </div>

              <div className="mt-8 flex flex-wrap gap-4">
                <button className="px-6 py-3 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors">
                  Download CV
                </button>
                <button className="px-6 py-3 border border-cyan-400 text-cyan-400 rounded-lg hover:bg-cyan-400/10 transition-colors">
                  View Certificates
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat) => (
                <div key={stat.label} className="p-6 rounded-xl bg-gray-800/50 hover:bg-gray-800/70 transition-colors">
                  <stat.icon className="h-8 w-8 text-cyan-400 mb-4" />
                  <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                  <div className="text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}