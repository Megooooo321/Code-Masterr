import { ArrowRight, Github, Linkedin, Download, Mail } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="glass-card rounded-2xl p-8 md:p-12 text-center md:text-left">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <span className="inline-block px-4 py-2 rounded-full bg-cyan-500/10 text-cyan-400 text-sm mb-6">
                Full Stack Developer
              </span>
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                Hi, I'm Ahmed
                <span className="text-cyan-400"> Magdy Farouk</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8">
                Full-stack developer specializing in creating innovative web solutions.
                Turning complex problems into elegant, user-friendly applications.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <a
                  href="#projects"
                  className="inline-flex items-center px-6 py-3 rounded-lg bg-cyan-500 text-white hover:bg-cyan-600 transition-colors"
                >
                  View Projects
                  <ArrowRight className="ml-2 h-5 w-5" />
                </a>
                <a
                  href="#contact"
                  className="inline-flex items-center px-6 py-3 rounded-lg border border-cyan-400 text-cyan-400 hover:bg-cyan-400/10 transition-colors"
                >
                  Contact Me
                  <Mail className="ml-2 h-5 w-5" />
                </a>
              </div>
              <div className="flex gap-4">
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-lg bg-gray-800 text-gray-300 hover:text-white hover:bg-gray-700 transition-colors"
                >
                  <Github className="h-5 w-5" />
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-lg bg-gray-800 text-gray-300 hover:text-white hover:bg-gray-700 transition-colors"
                >
                  <Linkedin className="h-5 w-5" />
                </a>
                <a
                  href="/resume.pdf"
                  className="p-3 rounded-lg bg-gray-800 text-gray-300 hover:text-white hover:bg-gray-700 transition-colors"
                >
                  <Download className="h-5 w-5" />
                </a>
              </div>
            </div>
            <div className="hidden md:block">
              <img
                src="https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?auto=format&fit=crop&w=800&q=80"
                alt="Ahmed Magdy"
                className="rounded-full w-80 h-80 object-cover mx-auto border-4 border-cyan-400/20"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}