import { Github, ExternalLink } from 'lucide-react';

const projects = [
  {
    title: 'AI Code Assistant',
    description: 'Real-time code analysis and suggestions powered by machine learning',
    image: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=800&q=80',
    tags: ['React', 'Python', 'TensorFlow'],
    github: '#',
    demo: '#'
  },
  {
    title: 'Cloud DevOps Platform',
    description: 'Automated deployment and scaling solution for cloud applications',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80',
    tags: ['Docker', 'Kubernetes', 'AWS'],
    github: '#',
    demo: '#'
  },
  {
    title: 'Blockchain Explorer',
    description: 'Interactive blockchain visualization and analysis tool',
    image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=800&q=80',
    tags: ['Web3.js', 'Node.js', 'D3.js'],
    github: '#',
    demo: '#'
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
            Featured <span className="text-cyan-400">Projects</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div
                key={index}
                className="rounded-xl overflow-hidden bg-gray-800/50 hover:bg-gray-800/70 transition-all duration-300 transform hover:-translate-y-2"
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-white mb-2">{project.title}</h3>
                  <p className="text-gray-400 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map((tag, tagIndex) => (
                      <span
                        key={tagIndex}
                        className="px-3 py-1 rounded-full text-sm bg-cyan-500/10 text-cyan-400"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-4">
                    <a
                      href={project.github}
                      className="flex items-center text-gray-400 hover:text-cyan-400 transition-colors"
                    >
                      <Github className="h-5 w-5 mr-2" />
                      Code
                    </a>
                    <a
                      href={project.demo}
                      className="flex items-center text-gray-400 hover:text-cyan-400 transition-colors"
                    >
                      <ExternalLink className="h-5 w-5 mr-2" />
                      Demo
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}