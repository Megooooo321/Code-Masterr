import { Code, Database, Layout, Server, Terminal, Workflow } from 'lucide-react';

const skills = [
  {
    category: 'Frontend',
    icon: Layout,
    items: ['React', 'TypeScript', 'Tailwind CSS', 'Next.js']
  },
  {
    category: 'Backend',
    icon: Server,
    items: ['Node.js', 'Python', 'Java', 'GraphQL']
  },
  {
    category: 'Database',
    icon: Database,
    items: ['PostgreSQL', 'MongoDB', 'Redis', 'Firebase']
  },
  {
    category: 'DevOps',
    icon: Workflow,
    items: ['Docker', 'AWS', 'CI/CD', 'Kubernetes']
  },
  {
    category: 'Tools',
    icon: Terminal,
    items: ['Git', 'VS Code', 'Postman', 'Linux']
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
            Technical <span className="text-cyan-400">Expertise</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {skills.map((skill) => (
              <div key={skill.category} className="p-6 rounded-xl bg-gray-800/50 hover:bg-gray-800/70 transition-colors">
                <div className="flex items-center mb-4">
                  <skill.icon className="h-6 w-6 text-cyan-400" />
                  <h3 className="ml-3 text-xl font-semibold text-white">{skill.category}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {skill.items.map((item) => (
                    <span
                      key={item}
                      className="px-3 py-1 rounded-full text-sm bg-cyan-500/10 text-cyan-400"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}