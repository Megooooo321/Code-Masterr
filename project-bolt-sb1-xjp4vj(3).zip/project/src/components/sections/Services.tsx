import { Code, Database, Layout, Server, Terminal, Workflow } from 'lucide-react';

const services = [
  {
    icon: Layout,
    title: 'Frontend Development',
    description: 'Creating responsive and interactive user interfaces using React, HTML5, CSS3, and modern JavaScript.'
  },
  {
    icon: Server,
    title: 'Backend Development',
    description: 'Building robust server-side applications with Node.js, Express, and various databases.'
  },
  {
    icon: Database,
    title: 'Database Design',
    description: 'Designing and implementing efficient database structures using SQL and NoSQL solutions.'
  },
  {
    icon: Code,
    title: 'API Development',
    description: 'Creating RESTful APIs and integrating third-party services for seamless functionality.'
  },
  {
    icon: Terminal,
    title: 'Technical Consultation',
    description: 'Providing expert advice on technology stack selection and architecture design.'
  },
  {
    icon: Workflow,
    title: 'Web Optimization',
    description: 'Improving website performance, SEO, and user experience through modern best practices.'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
            My <span className="text-cyan-400">Services</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="p-6 rounded-xl bg-gray-800/50 hover:bg-gray-800/70 transition-all duration-300 transform hover:-translate-y-2"
              >
                <service.icon className="h-12 w-12 text-cyan-400 mb-4" />
                <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                <p className="text-gray-400">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}